[![Build Status](https://travis-ci.org/wibosco/CoreDataMigrationRevised-Example.svg)](https://travis-ci.org/wibosco/CoreDataMigrationRevised-Example)
<a href="https://swift.org"><img src="https://img.shields.io/badge/Swift-4.2-orange.svg?style=flat" alt="Swift" /></a>
<a href="https://twitter.com/wibosco"><img src="https://img.shields.io/badge/twitter-@wibosco-blue.svg?style=flat" alt="Twitter: @wibosco" /></a>

# CoreDataMigration-Example
An example project showing how we can implement progressive Core Data migrations as shown in this article - https://williamboles.me/progressive-core-data-migration/
