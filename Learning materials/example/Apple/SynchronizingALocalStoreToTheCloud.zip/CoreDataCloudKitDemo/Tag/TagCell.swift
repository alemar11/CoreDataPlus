/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A UITableViewCell subclass for showing a tag.
*/

import UIKit

class TagCell: UITableViewCell {
    @IBOutlet weak var nameLabel: TagLabel!
}

