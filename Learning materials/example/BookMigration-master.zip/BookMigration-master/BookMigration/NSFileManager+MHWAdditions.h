//
//  NSFileManager+MHWAdditions.h
//  BookMigration
//
//  Created by Martin Hwasser on 8/26/13.
//  Copyright (c) 2013 Martin Hwasser. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSFileManager (MHWAdditions)

+ (NSURL *)urlToApplicationSupportDirectory;

@end
