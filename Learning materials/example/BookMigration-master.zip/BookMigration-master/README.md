BookMigration
=============

Simple app that demonstrates Core Data migration as code example accompanying the objc.io article [Custom Core Data Migrations](http://www.objc.io/issue-4/core-data-migration.html).


##Credits
Thanks to [Gideon Wald](mailto:gideon@welkinhealth.com) and [Benedikt Hirmer](https://github.com/bhr) for pointing out an issue with SQLite's [write-ahead logging](https://github.com/hwaxxer/BookMigration/commit/baa5014391081e7b74223250281e3cad90603c56). 
