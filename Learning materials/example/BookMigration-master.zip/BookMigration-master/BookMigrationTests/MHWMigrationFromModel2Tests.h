//
//  MHWMigrationFromModel2Tests.h
//  BookMigration
//
//  Created by Martin Hwasser on 9/1/13.
//  Copyright (c) 2013 Martin Hwasser. All rights reserved.
//

#import "MHWCoreDataTests.h"

@interface MHWMigrationFromModel2Tests : MHWCoreDataTests

@end
